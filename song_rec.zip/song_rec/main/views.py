from django.shortcuts import render
import pandas as pd

recs_df = pd.read_csv('data/recs.csv')
index_df = pd.read_csv('data/indices.csv', index_col='track_name')

def home(request):
    if request.method == "POST":
        track_name = request.POST.get('song')
        song_index = index_df['index'][track_name]
        top_10_recs = index_df.iloc[recs_df.iloc[song_index, :], :]
        
        recs_list = []
        for index, col in top_10_recs.iterrows():
            recs_list.append([index, col['track_id']])
        context = {
            'recs': recs_list
        }
        return render(request, 'index.html', context)
    else:
        return render(request, 'index.html')